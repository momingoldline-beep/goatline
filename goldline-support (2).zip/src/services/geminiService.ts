import { GoogleGenAI, Type } from "@google/genai";

let aiClient: GoogleGenAI | null = null;

function getAiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'undefined') {
      throw new Error("Gemini API key is not configured. Please ensure GEMINI_API_KEY is set in your environment variables or AI Studio settings.");
    }
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

export async function parseQuotationInquiry(text: string) {
  // We use the model name recommended for complex text/coding tasks in the skill
  const modelName = "gemini-3.1-pro-preview";
  const ai = getAiClient();

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: `Analyze this email and extract detailed transport quotation movements. Today is ${new Date().toLocaleDateString()}.
      
      Email Text:
      ${text}`,
      config: {
        systemInstruction: `You are a transport quotation assistant for Goldline Executive Travel.
Your task is to parse unstructured inquiries into structured JSON.

OPERATIONAL RULES:
1. MULTIPLE DATES: Treat each separate date Mentioned as a separate "Movement".
2. JOURNEY TYPE: Identify if one-way (single) or return trip per movement.
3. PASSENGERS: Extract the passenger count for EACH movement.
4. UNRELATED NOTES: Put anything unrelated (signatures, chatter) into "unrelatedNotes".
5. Vehicle Capacity must be one of: '8 Seater', '16 Seater', '19 Seater', '22 Seater', '34 Seater', '43 Seater', '49 Seater', '53 Seater', '57 Seater', '70 Seater', '84 Seater'.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            customerName: { type: Type.STRING },
            customerEmail: { type: Type.STRING },
            customerPhone: { type: Type.STRING },
            wheelchairs: { type: Type.NUMBER },
            extraLuggage: { type: Type.STRING },
            additionalNotes: { type: Type.STRING },
            unrelatedNotes: { type: Type.STRING },
            vehicleType: { type: Type.STRING },
            movements: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  date: { type: Type.STRING },
                  passengers: { type: Type.NUMBER },
                  vehicleCapacity: { type: Type.STRING },
                  vehicleQuantity: { type: Type.NUMBER },
                  returnRequired: { type: Type.BOOLEAN },
                  outbound: {
                    type: Type.OBJECT,
                    properties: {
                      time: { type: Type.STRING },
                      pickup: { type: Type.STRING },
                      destination: { type: Type.STRING }
                    },
                    required: ["time", "pickup", "destination"]
                  },
                  additionalPickups: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        location: { type: Type.STRING },
                        time: { type: Type.STRING }
                      },
                      required: ["location"]
                    }
                  },
                  return: {
                    type: Type.OBJECT,
                    properties: {
                      time: { type: Type.STRING },
                      pickup: { type: Type.STRING },
                      destination: { type: Type.STRING }
                    }
                  },
                  notes: { type: Type.STRING }
                },
                required: ["id", "date", "passengers", "vehicleCapacity", "vehicleQuantity", "returnRequired", "outbound"]
              }
            },
            internalNotes: { type: Type.STRING }
          },
          required: ["movements"]
        }
      }
    });

    const parsedData = JSON.parse(response.text || "{}");
    parsedData.status = 'Draft';
    
    // Calculate total passengers as the max across movements for high-level info
    if (parsedData.movements) {
      parsedData.totalPassengers = Math.max(...parsedData.movements.map((m: any) => m.passengers || 0));
    }
    
    return parsedData;
  } catch (error: any) {
    console.error("Gemini Parsing Error:", error);
    
    // Check if the error is related to authentication/key
    if (error.message?.includes('403') || error.message?.includes('API_KEY_INVALID') || error.message?.includes('401')) {
      throw new Error("AI Assistant authorization failed. Please ensure the Gemini API key is correctly configured in the environment settings.");
    }
    
    throw error;
  }
}
