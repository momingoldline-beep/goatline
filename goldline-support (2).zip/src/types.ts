export type VehicleCapacity = 
  | '8 Seater' 
  | '16 Seater' 
  | '19 Seater' 
  | '22 Seater' 
  | '34 Seater' 
  | '43 Seater' 
  | '49 Seater' 
  | '53 Seater' 
  | '57 Seater' 
  | '70 Seater' 
  | '84 Seater';

export type VehicleType = 'Standard' | 'Executive' | 'Party Bus';

export type QuotationStatus = 'Draft' | 'Sent' | 'Confirmed' | 'Cancelled';

export interface PickupStop {
  location: string;
  time: string;
}

export interface Movement {
  id: string;
  date: string;
  outbound: {
    time: string;
    pickup: string;
    destination: string;
  };
  additionalPickups: PickupStop[];
  returnRequired: boolean;
  return?: {
    time: string;
    pickup: string;
    destination: string;
  };
  passengers: number;
  vehicleCapacity: VehicleCapacity;
  vehicleQuantity: number;
  separateVehicleSpecs?: {
    capacity: VehicleCapacity;
    pax: number;
  }[];
  notes: string;
}

export interface Quotation {
  id?: string;
  reference: string;
  customerName?: string;
  customerEmail: string;
  customerPhone: string;
  
  // Multi-Movement Support
  movements: Movement[];
  
  // Totals / General Info
  totalPassengers?: number; // Calculated or sum
  wheelchairs: number;
  extraLuggage: string;
  additionalNotes: string;
  unrelatedNotes: string; // "Anything mentioned not related to the quotation"
  
  // Global Vehicle Preferences
  vehicleType: VehicleType;
  
  // Admin Notes
  internalNotes: string;
  status: QuotationStatus;
  
  // Audit info
  createdBy?: string;
  createdByEmail?: string;
  createdByName?: string;
  
  createdAt: any;
  updatedAt: any;
}

export interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  createdAt: string;
  isBanned?: boolean;
  isOnline?: boolean;
  isAdmin?: boolean;
}
