/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { auth, logout } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { BusFront, ArrowRight, ShieldCheck, Mail } from 'lucide-react';
import Sidebar from './components/Sidebar';
import QuotationForm from './components/QuotationForm';
import SavedQuotations from './components/SavedQuotations';
import QuotationDetail from './components/QuotationDetail';
import VehicleDetails from './components/VehicleDetails';
import AirportParking from './components/AirportParking';
import UserManagement from './components/UserManagement';
import LoginManager from './components/LoginManager';
import AccessGate from './components/AccessGate';
import AIChat from './components/AIChat';
import { Quotation } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { db } from './lib/firebase';
import { doc, updateDoc, onSnapshot } from 'firebase/firestore';
import { Ban, Trash2, LogOut, Loader2 } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [activeView, setActiveView] = useState<'new' | 'list' | 'vehicles' | 'parking' | 'ai-chat' | 'users'>('list');
  const [editingQuotation, setEditingQuotation] = useState<Quotation | undefined>(undefined);
  const [viewingQuotation, setViewingQuotation] = useState<Quotation | null>(null);
  const [securityStatus, setSecurityStatus] = useState<'active' | 'banned' | 'deleted'>('active');

  // AI Chat Persistence State
  const [aiInput, setAiInput] = useState(() => localStorage.getItem('goldline_ai_input') || '');
  const [aiResult, setAiResult] = useState(() => {
    const saved = localStorage.getItem('goldline_ai_result');
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    localStorage.setItem('goldline_ai_input', aiInput);
  }, [aiInput]);

  useEffect(() => {
    localStorage.setItem('goldline_ai_result', JSON.stringify(aiResult));
  }, [aiResult]);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) {
        setIsUnlocked(false);
        setSecurityStatus('active');
      }
      setAuthReady(true);
      
      // Update online status
      if (u) {
        updateDoc(doc(db, 'users', u.uid), { isOnline: true }).catch(() => {});
      }
    });

    const handleDisconnect = () => {
      if (auth.currentUser) {
        updateDoc(doc(db, 'users', auth.currentUser.uid), { isOnline: false }).catch(() => {});
      }
    };

    window.addEventListener('beforeunload', handleDisconnect);
    return () => {
      unsubscribeAuth();
      window.removeEventListener('beforeunload', handleDisconnect);
    };
  }, []);

  // Real-time security listener
  useEffect(() => {
    if (!user) return;

    const unsubscribeSecurity = onSnapshot(doc(db, 'users', user.uid), (snapshot) => {
      if (!snapshot.exists()) {
        setSecurityStatus('deleted');
        // Auto logout after a delay
        setTimeout(() => logout(), 4000);
      } else {
        const data = snapshot.data();
        if (data?.isBanned) {
          setSecurityStatus('banned');
          // Auto logout after a delay
          setTimeout(() => logout(), 4000);
        } else {
          setSecurityStatus('active');
        }
      }
    }, (err) => {
      console.error("Security monitor error:", err);
      // If we can't read the doc, it might be permission denied (deleted)
      if (err.message.includes('permission-denied')) {
        // We don't want to jump the gun if it's just a transient error
        // but if it persists, we could assume deletion
      }
    });

    return () => unsubscribeSecurity();
  }, [user]);

  const handleEdit = (q: Quotation) => {
    setEditingQuotation(q);
    setActiveView('new');
  };

  const handleAIChatComplete = (data: any) => {
    setEditingQuotation(data);
    setActiveView('new');
  };

  const handleSuccess = () => {
    setEditingQuotation(undefined);
    setActiveView('list');
  };

  const handleLogout = async () => {
    if (user) {
      try {
        await updateDoc(doc(db, 'users', user.uid), { isOnline: false });
      } catch (e) {}
    }
    logout();
  };

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
          <p className="text-slate-500 font-bold uppercase tracking-[0.3em] text-[10px]">Initializing</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginManager />;
  }

  if (!isUnlocked) {
    return (
      <AccessGate 
        displayName={user.displayName || user.email || 'Staff Member'} 
        onUnlock={() => setIsUnlocked(true)}
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div className="flex bg-slate-900 min-h-screen text-slate-200">
      <Sidebar 
        activeView={activeView} 
        onViewChange={(v) => {
          setActiveView(v);
          setEditingQuotation(undefined);
        }} 
        user={user}
        onLogout={handleLogout}
      />

      <main className="flex-1 min-w-0 h-screen overflow-y-auto no-scrollbar relative">
        <div className="max-w-6xl mx-auto p-8 relative">
          <AnimatePresence mode="wait">
            {activeView === 'ai-chat' && (
              <motion.div
                key="ai-chat"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              >
                <AIChat 
                  onParseComplete={handleAIChatComplete} 
                  persistedInput={aiInput}
                  setPersistedInput={setAiInput}
                  persistedResult={aiResult}
                  setPersistedResult={setAiResult}
                />
              </motion.div>
            )}

            {activeView === 'new' && (
              <motion.div
                key="new-quotation"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              >
                <QuotationForm 
                  initialData={editingQuotation} 
                  onSuccess={handleSuccess} 
                  onCancel={() => {
                    setActiveView('list');
                    setEditingQuotation(undefined);
                  }}
                />
              </motion.div>
            )}
            
            {activeView === 'list' && (
              <motion.div
                key="saved-quotations"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              >
                <SavedQuotations 
                  onEdit={handleEdit} 
                  onView={setViewingQuotation}
                />
              </motion.div>
            )}

            {activeView === 'vehicles' && (
              <motion.div
                key="vehicle-details"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              >
                <VehicleDetails />
              </motion.div>
            )}

            {activeView === 'parking' && (
              <motion.div
                key="airport-parking"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              >
                <AirportParking />
              </motion.div>
            )}

            {activeView === 'users' && (
              <motion.div
                key="user-management"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              >
                <UserManagement />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Viewing Modal */}
      {viewingQuotation && (
        <QuotationDetail 
          quotation={viewingQuotation} 
          onClose={() => setViewingQuotation(null)} 
        />
      )}

      {/* Security Overlays */}
      <AnimatePresence>
        {securityStatus !== 'active' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] bg-slate-900/95 backdrop-blur-xl flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-sm glass bg-slate-900 border border-white/5 rounded-[3rem] p-10 text-center shadow-2xl relative overflow-hidden"
            >
              {/* Animated Danger Background */}
              <div className="absolute inset-0 bg-red-500/5 animate-pulse" />
              
              <div className="relative z-10">
                <div className="w-24 h-24 bg-red-500/10 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-red-500/20 shadow-lg shadow-red-500/10">
                  {securityStatus === 'banned' ? (
                    <Ban size={48} className="text-red-500 animate-bounce" />
                  ) : (
                    <Trash2 size={48} className="text-red-500 animate-bounce" />
                  )}
                </div>

                <h2 className="text-3xl font-black text-white mb-4 tracking-tight">
                  {securityStatus === 'banned' ? 'Account Banned' : 'Account Deleted'}
                </h2>
                
                <p className="text-slate-400 text-sm font-medium mb-8 leading-relaxed">
                  {securityStatus === 'banned' 
                    ? 'Your access to the Goldline Support Portal has been revoked by an administrator.' 
                    : 'This staff account has been permanently removed from the system.'}
                </p>

                <div className="flex flex-col items-center gap-4">
                  <div className="flex items-center gap-2 text-slate-500 font-bold uppercase tracking-widest text-[10px]">
                    <Loader2 size={12} className="animate-spin" />
                    <span>Signing out in 4 seconds</span>
                  </div>
                  
                  <button 
                    onClick={() => logout()}
                    className="w-full py-4 bg-white/5 hover:bg-red-500/10 border border-white/5 hover:border-red-500/20 text-slate-400 hover:text-red-400 font-bold rounded-2xl transition-all flex items-center justify-center gap-2"
                  >
                    <LogOut size={18} />
                    Exit Now
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
