import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, ShieldCheck, ArrowRight, BusFront, LogOut } from 'lucide-react';

interface AccessGateProps {
  onUnlock: () => void;
  onLogout: () => void;
  displayName: string;
}

const ACCESS_KEY = 'Goldline1000';

export default function AccessGate({ onUnlock, onLogout, displayName }: AccessGateProps) {
  const [key, setKey] = useState('');
  const [error, setError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    
    // Slight delay for effect
    setTimeout(() => {
      if (key === ACCESS_KEY) {
        onUnlock();
      } else {
        setError('Invalid access key. Access denied.');
        setKey('');
        setIsVerifying(false);
      }
    }, 600);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-amber-500/5 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-amber-500/5 rounded-full blur-[120px]" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="glass bg-slate-900/80 p-10 rounded-[2.5rem] shadow-2xl border border-white/5 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-lg shadow-amber-500/20">
            <Lock className="text-slate-900" size={32} />
          </div>
          
          <h2 className="text-2xl font-black text-white tracking-tight mb-2">Staff Portal</h2>
          <p className="text-slate-400 text-xs mb-8 leading-relaxed uppercase tracking-widest font-bold">
            Internal Access Only
          </p>
          <p className="text-slate-500 text-[10px] mb-8 leading-relaxed italic">
            Please enter your provided Staff Access Key to unlock the quotation system. 
            (This is for internal security and is not an AI API key).
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 shrink-0" size={18} />
              <input
                type="password"
                required
                autoFocus
                value={key}
                onChange={(e) => {
                   setKey(e.target.value);
                   setError('');
                }}
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all text-center tracking-[0.5em] font-black"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <motion.p 
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-red-400 text-xs font-bold uppercase tracking-widest bg-red-400/5 py-3 rounded-xl border border-red-400/10"
              >
                {error}
              </motion.p>
            )}

            <button
              disabled={isVerifying}
              className="w-full py-4 bg-white hover:bg-slate-100 text-slate-900 font-bold rounded-2xl transition-all flex items-center justify-center gap-3 shadow-xl hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50"
            >
              {isVerifying ? (
                <div className="w-5 h-5 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin" />
              ) : (
                <>
                  Unlock Portal
                  <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>
          
          <button 
            onClick={onLogout}
            className="mt-8 flex items-center justify-center gap-2 mx-auto text-slate-500 hover:text-white transition-colors text-[10px] font-bold uppercase tracking-widest px-4 py-2 hover:bg-white/5 rounded-lg"
          >
            <LogOut size={14} />
            Switch Account / Logout
          </button>
          
          <div className="mt-8 pt-8 border-t border-white/5 flex items-center justify-center gap-2 text-slate-600 text-[10px] font-bold uppercase tracking-widest">
            <ShieldCheck size={14} />
            <span>Identity Verified</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
