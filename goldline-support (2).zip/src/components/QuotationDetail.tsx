import React from 'react';
import { Quotation, Movement } from '../types';
import { 
  X, Calendar, Clock, MapPin, Users, Luggage, MessageSquare, 
  Briefcase, Phone, Mail, TrendingUp, Info, Download, ShieldCheck,
  ArrowRight, MoveHorizontal, BusFront, Hash
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';
import { safeDateFormat } from '../lib/date-utils';

interface QuotationDetailProps {
  quotation: Quotation;
  onClose: () => void;
}

export default function QuotationDetail({ quotation, onClose }: QuotationDetailProps) {
  const renderMovement = (m: Movement, index: number) => (
    <div key={m.id || index} className="space-y-6 animate-in slide-in-from-left-4 duration-300" style={{ animationDelay: `${index * 100}ms` }}>
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500 font-black text-xs">
          {index + 1}
        </div>
        <h4 className="text-sm font-black uppercase tracking-[0.2em] text-slate-300">Movement {index + 1}</h4>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Outbound Detail */}
        <div className="bg-slate-900/40 p-6 rounded-2xl border border-slate-800 space-y-4 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
            <ArrowRight size={40} className="text-green-500" />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-widest text-green-500 underline underline-offset-4 decoration-green-500/30">Outbound Journey</span>
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Calendar size={14} className="text-amber-500" />
              <span className="text-sm font-bold text-white">{safeDateFormat(m.date, 'EEEE, dd MMM yyyy')}</span>
            </div>
            <div className="flex items-start gap-3">
              <Clock size={14} className="text-amber-500 mt-1" />
              <div>
                <p className="text-sm font-black text-white">{m.outbound.time || 'Time TBC'}</p>
                <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Pickup Time</p>
              </div>
            </div>
            <div className="space-y-4 pt-2 relative">
               <div className="absolute left-1.5 top-3 bottom-3 w-px bg-slate-800" />
               <div className="relative pl-6">
                 <div className="absolute left-0 top-1 w-3 h-3 rounded-full border-2 border-amber-500 bg-slate-900 shadow-[0_0_8px_rgba(251,191,36,0.2)]" />
                 <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">From</p>
                 <p className="text-xs font-bold text-slate-200">{m.outbound.pickup || 'Unspecified'}</p>
               </div>

               {/* Additional waypoints */}
               {m.additionalPickups && m.additionalPickups.length > 0 && m.additionalPickups.map((p, pIdx) => (
                 <div key={pIdx} className="relative pl-6 border-l border-dashed border-slate-700 ml-1.5 pb-2">
                   <div className="absolute -left-[5px] top-1 w-2 h-2 rounded-full border border-slate-500 bg-slate-900" />
                   <p className="text-[9px] text-slate-600 uppercase font-bold tracking-widest">Stop {pIdx + 1} {p.time && `(@ ${p.time})`}</p>
                   <p className="text-[10px] font-bold text-slate-400">{p.location}</p>
                 </div>
               ))}

               <div className="relative pl-6">
                 <div className="absolute left-0 top-1 w-3 h-3 rounded-full bg-amber-500 shadow-[0_0_12px_rgba(251,191,36,0.4)]" />
                 <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">To</p>
                 <p className="text-xs font-bold text-white">{m.outbound.destination || 'Unspecified'}</p>
               </div>
            </div>
          </div>
        </div>

        {/* Return Detail */}
        {m.returnRequired ? (
          <div className="bg-amber-500/5 p-6 rounded-2xl border border-amber-500/20 space-y-4 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
              <MoveHorizontal size={40} className="text-amber-500" />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-amber-500 underline underline-offset-4 decoration-amber-500/30">Return Journey</span>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Calendar size={14} className="text-amber-500" />
                <span className="text-sm font-bold text-white">{safeDateFormat(m.date, 'EEEE, dd MMM yyyy')}</span>
              </div>
              <div className="flex items-start gap-3">
                <Clock size={14} className="text-amber-500 mt-1" />
                <div>
                  <p className="text-sm font-black text-white">{m.return?.time || 'Time TBC'}</p>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Return Pickup Time</p>
                </div>
              </div>
              <div className="space-y-4 pt-2 relative">
                 <div className="absolute left-1.5 top-3 bottom-3 w-px bg-slate-800" />
                 <div className="relative pl-6">
                   <div className="absolute left-0 top-1 w-3 h-3 rounded-full border-2 border-slate-600 bg-slate-900" />
                   <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Pickup Back From</p>
                   <p className="text-xs font-bold text-slate-200">{m.return?.pickup || 'Unspecified'}</p>
                 </div>
                 <div className="relative pl-6">
                   <div className="absolute left-0 top-1 w-3 h-3 rounded-full bg-slate-600" />
                   <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Dropping Back To</p>
                   <p className="text-xs font-bold text-white">{m.return?.destination || 'Unspecified'}</p>
                 </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-slate-900/20 p-6 rounded-2xl border border-slate-800/50 flex flex-col items-center justify-center text-center space-y-2 opacity-60 grayscale border-dashed">
             <MoveHorizontal size={24} className="text-slate-700" />
             <p className="text-[10px] font-bold text-slate-600 uppercase tracking-[0.2em]">One-Way Only</p>
             <p className="text-[9px] text-slate-700 max-w-[150px]">No return journey specified for this trip movement.</p>
          </div>
        )}
      </div>

      {/* Movement Specs & Separate Vehicles */}
      <div className="space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
           <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Capacity</p>
              <p className="text-xs font-black text-amber-500">{m.vehicleCapacity}</p>
           </div>
           <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Quantity</p>
              <p className="text-xs font-black text-white">{m.vehicleQuantity}x Vehicle{m.vehicleQuantity > 1 ? 's' : ''}</p>
           </div>
           {m.notes && (
             <div className="col-span-2 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Movement Notes</p>
                <p className="text-[10px] font-medium text-slate-400 italic line-clamp-1">"{m.notes}"</p>
             </div>
           )}
        </div>

        {m.separateVehicleSpecs && m.separateVehicleSpecs.length > 0 && (
          <div className="p-4 bg-slate-900/40 rounded-2xl border border-slate-800/50">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] mb-3">Individual Vehicle Loadout</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {m.separateVehicleSpecs.map((spec, sIdx) => (
                <div key={sIdx} className="bg-slate-900/40 p-2 rounded-lg border border-slate-800 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-slate-400">#{sIdx + 1}</span>
                  <div className="text-right">
                    <p className="text-[9px] font-black text-amber-500">{spec.capacity}</p>
                    <p className="text-[8px] text-slate-500">{spec.pax} PAX</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="border-b border-slate-800/50 pt-4" />
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="glass bg-slate-900 w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-[2rem] shadow-2xl flex flex-col animate-in zoom-in-95 duration-300 no-scrollbar border border-slate-800">
        {/* Header */}
        <div className="sticky top-0 bg-slate-900/90 backdrop-blur-xl border-b border-slate-800 p-6 md:p-8 flex justify-between items-center z-10">
          <div>
            <div className="flex items-center gap-4">
              <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">Quotation Review</h2>
              <span className={cn(
                "px-3 py-1 rounded-full text-[9px] font-black border uppercase tracking-[0.15em] shadow-lg",
                quotation.status === 'Draft' ? 'bg-slate-800 text-slate-400 border-slate-700' :
                quotation.status === 'Sent' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                quotation.status === 'Confirmed' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                'bg-red-500/20 text-red-400 border-red-500/30'
              )}>
                {quotation.status}
              </span>
            </div>
            <p className="text-[10px] uppercase tracking-widest text-slate-500 mt-2 font-mono font-medium flex items-center gap-2 flex-wrap">
              Reference: <span className="text-amber-500 font-bold">{quotation.reference}</span> 
              <span className="opacity-30">|</span> 
              Movements: <span className="text-white font-bold">{quotation.movements?.length || 0}</span>
              <span className="opacity-30">|</span>
              Created By: <span className="text-slate-300 font-bold">{quotation.createdByName || 'System'}</span>
            </p>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-slate-800 rounded-2xl transition-all border border-transparent hover:border-slate-700 group">
            <X size={24} className="text-slate-500 group-hover:text-white" />
          </button>
        </div>

        <div className="p-6 md:p-10 grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Itinerary */}
          <div className="lg:col-span-12 xl:col-span-8 space-y-12">
            
            {/* Customer Section */}
            <section className="space-y-6">
              <div className="flex items-center gap-3 text-amber-500">
                <Briefcase size={16} />
                <h3 className="font-bold uppercase tracking-[0.2em] text-[10px]">Client Overview</h3>
              </div>
              <div className="bg-slate-900/40 p-6 rounded-3xl border border-slate-800/50 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-inner">
                <div>
                  <p className="text-2xl font-black text-white tracking-tight">{quotation.customerName || 'Guest Client'}</p>
                  <div className="flex gap-6 mt-3">
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <Mail size={12} className="text-slate-600" /> {quotation.customerEmail || 'No Email'}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <Phone size={12} className="text-slate-600" /> {quotation.customerPhone || 'No Phone'}
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2 text-right">
                   <div className="px-4 py-2 bg-slate-900 rounded-xl border border-slate-800">
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Vehicle Class</p>
                      <p className="text-xs font-bold text-amber-500">{quotation.vehicleType}</p>
                   </div>
                </div>
              </div>
            </section>

            {/* Movements Section */}
            <section className="space-y-8">
              <div className="flex items-center gap-3 text-amber-500">
                <TrendingUp size={16} />
                <h3 className="font-bold uppercase tracking-[0.2em] text-[10px]">Itinerary Movements</h3>
              </div>
              
              <div className="space-y-10">
                {quotation.movements?.map((m, i) => renderMovement(m, i))}
              </div>
            </section>
          </div>

          {/* Right Column: Global Specs & Notes */}
          <div className="lg:col-span-12 xl:col-span-4 space-y-10">
            {/* Global Summary Card */}
            <section className="p-6 bg-slate-900/60 rounded-[2rem] border border-slate-800 shadow-2xl space-y-8">
               <div className="flex items-center gap-3 text-amber-500 border-b border-slate-800 pb-4">
                 <Users size={18} />
                 <h3 className="font-bold uppercase tracking-[0.1em] text-xs">Global Manifest</h3>
               </div>

               <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                     <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Max PAX</p>
                     <p className="text-3xl font-black text-white">{quotation.totalPassengers || 0}</p>
                  </div>
                  <div className="space-y-1">
                     <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Wheelchairs</p>
                     <p className="text-3xl font-black text-white">{quotation.wheelchairs}</p>
                  </div>
               </div>

               <div className="space-y-6 pt-4">
                  {quotation.extraLuggage && (
                    <div className="space-y-2">
                       <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                         <Luggage size={14} className="text-amber-500" /> Luggage Info
                       </p>
                       <p className="text-xs text-slate-300 bg-slate-900/50 p-4 rounded-xl border border-slate-800 leading-relaxed italic">
                         "{quotation.extraLuggage}"
                       </p>
                    </div>
                  )}

                  {quotation.unrelatedNotes && (
                    <div className="space-y-2">
                       <p className="text-[10px] font-black text-red-400 uppercase tracking-widest flex items-center gap-2">
                         <MessageSquare size={14} /> Unrelated Mentions
                       </p>
                       <p className="text-xs text-red-300/80 bg-red-950/20 p-4 rounded-xl border border-red-500/10 leading-relaxed italic">
                         "{quotation.unrelatedNotes}"
                       </p>
                    </div>
                  )}

                  {quotation.additionalNotes && (
                    <div className="space-y-2">
                       <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                         <MessageSquare size={14} className="text-amber-500" /> Public Notes
                       </p>
                       <p className="text-xs text-slate-400 bg-slate-900/50 p-4 rounded-xl border border-slate-800 leading-relaxed">
                         "{quotation.additionalNotes}"
                       </p>
                    </div>
                  )}

                  {quotation.internalNotes && (
                    <div className="space-y-2">
                       <p className="text-[10px] font-black text-amber-500/60 uppercase tracking-widest flex items-center gap-2">
                         <ShieldCheck size={14} /> Internal Reasoning
                       </p>
                       <div className="p-4 bg-amber-500/5 rounded-xl border border-amber-500/10 text-[11px] text-slate-300 font-medium leading-relaxed">
                          {quotation.internalNotes}
                       </div>
                    </div>
                  )}
               </div>

               <button 
                onClick={() => window.print()}
                className="w-full py-4 gold-gradient rounded-2xl text-[10px] font-black text-slate-900 shadow-xl shadow-amber-600/20 hover:scale-[1.02] transition-all flex items-center justify-center gap-3 active:scale-95 mt-4"
              >
                <Download size={14} /> DOWNLOAD FULL QUOTE PDF
              </button>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
