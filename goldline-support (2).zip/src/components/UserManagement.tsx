import React, { useState, useEffect } from 'react';
import { 
  Users, ShieldCheck, Trash2, Ban, UserCheck, Search, 
  ArrowRight, Lock, Hash, Calendar, Mail, FileText,
  Activity, Circle, ChevronRight
} from 'lucide-react';
import { db } from '../lib/firebase';
import { 
  collection, query, onSnapshot, doc, 
  deleteDoc, updateDoc, getDocs, where 
} from 'firebase/firestore';
import { cn } from '../lib/utils';
import { safeDateFormat } from '../lib/date-utils';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  createdAt: string;
  isBanned?: boolean;
  isOnline?: boolean;
  isAdmin?: boolean;
  quotationCount?: number;
}

export default function UserManagement() {
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [loginStep, setLoginStep] = useState<'form' | 'authorized'>('form');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // Handle section login
  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'Momin' && password === 'Momin2626!') {
      setIsAuthorized(true);
      setLoginStep('authorized');
      setError('');
    } else {
      setError('Invalid master credentials.');
    }
  };

  useEffect(() => {
    if (!isAuthorized) return;

    const unsubscribe = onSnapshot(collection(db, 'users'), async (snapshot) => {
      const userDocs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as UserProfile[];

      // Fetch quotation counts for each user
      const updatedUsers = await Promise.all(userDocs.map(async (u) => {
        const usernameLower = u.username.toLowerCase().trim();
        const qCount = query(collection(db, 'quotations'), where('createdByEmail', '==', `${usernameLower}@goldline.portal`));
        const qSnap = await getDocs(qCount);
        return {
          ...u,
          quotationCount: qSnap.size
        };
      }));

      setUsers(updatedUsers);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [isAuthorized]);

  const toggleBan = async (user: UserProfile) => {
    try {
      await updateDoc(doc(db, 'users', user.id), {
        isBanned: !user.isBanned
      });
    } catch (err) {
      console.error("Error toggling ban:", err);
    }
  };

  const toggleAdmin = async (user: UserProfile) => {
    try {
      await updateDoc(doc(db, 'users', user.id), {
        isAdmin: !user.isAdmin
      });
    } catch (err) {
      console.error("Error toggling admin:", err);
    }
  };

  const deleteUser = async (id: string) => {
    if (!confirm('Are you sure you want to delete this user? This action is irreversible.')) return;
    try {
      await deleteDoc(doc(db, 'users', id));
    } catch (err) {
      console.error("Error deleting user:", err);
    }
  };

  const filteredUsers = users.filter(u => 
    u.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isAuthorized) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-sm glass bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl"
        >
          <div className="w-16 h-16 bg-amber-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-amber-500/20">
            <Lock size={32} className="text-amber-500" />
          </div>
          
          <h2 className="text-2xl font-black text-white text-center mb-2 tracking-tight">Access Restricted</h2>
          <p className="text-sm text-slate-500 text-center mb-8">Master credentials required to manage staff accounts.</p>

          <form onSubmit={handleAuth} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 ml-1">Username</label>
              <input
                autoComplete="off"
                data-lpignore="true"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 px-4 text-white placeholder-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500/30 transition-all text-sm"
                placeholder="Manager Username"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 ml-1">Password</label>
              <input
                autoComplete="new-password"
                data-lpignore="true"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 px-4 text-white placeholder-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500/30 transition-all text-sm"
                placeholder="••••••••"
              />
            </div>
            
            {error && (
              <p className="text-xs text-red-400 font-bold text-center bg-red-400/10 py-2 rounded-lg border border-red-400/20">
                {error}
              </p>
            )}

            <button
              type="submit"
              className="w-full py-4 bg-amber-500 hover:bg-amber-600 text-slate-900 font-black rounded-xl transition-all flex items-center justify-center gap-2 mt-4 active:scale-95"
            >
              Verify & Unlock
              <ArrowRight size={18} />
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-3xl font-black text-white tracking-tight">Staff Management</h2>
            <span className="px-2 py-0.5 bg-amber-500 text-slate-950 text-[10px] font-black rounded uppercase tracking-widest">Master View</span>
          </div>
          <p className="text-sm text-slate-500 font-medium max-w-md">Overview of all active personnel, their status, and historical quotation output.</p>
        </div>
        
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
          <input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-dark w-full pl-10 pr-4 py-2.5 rounded-xl text-xs"
            placeholder="Filter staff by name or username..."
          />
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* User Card List */}
        <div className="xl:col-span-3">
          <div className="glass rounded-3xl border border-slate-800 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-900/40 border-b border-slate-800">
                    <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Profile</th>
                    <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Presence</th>
                    <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Record</th>
                    <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Joined</th>
                    <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-20 text-center">
                        <div className="flex flex-col items-center gap-3">
                           <div className="w-8 h-8 border-2 border-amber-500/20 border-t-amber-500 rounded-full animate-spin" />
                           <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Fetching Personnel Data</p>
                        </div>
                      </td>
                    </tr>
                  ) : filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-20 text-center text-slate-500 italic text-sm">No personnel found matching your search.</td>
                    </tr>
                  ) : (
                    filteredUsers.map((u) => (
                      <tr key={u.id} className={cn("hover:bg-slate-800/20 transition-colors group", u.isBanned && "opacity-60 grayscale")}>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-2xl gold-gradient flex items-center justify-center text-slate-900 font-black text-lg shadow-lg shadow-amber-500/10">
                              {u.displayName[0].toUpperCase()}
                            </div>
                            <div>
                              <p className="text-sm font-black text-white tracking-tight">{u.displayName}</p>
                              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">@{u.username}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                             <Circle size={8} className={cn("fill-current", u.isOnline ? "text-green-500" : "text-slate-600")} />
                             <span className={cn("text-[10px] font-black uppercase tracking-widest", u.isOnline ? "text-green-500" : "text-slate-500")}>
                               {u.isOnline ? 'Online Now' : 'Offline'}
                             </span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                             <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
                               <FileText size={14} className="text-amber-500" />
                             </div>
                             <div>
                               <p className="text-xs font-black text-white">{u.quotationCount || 0}</p>
                               <p className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.1em]">Total Quotes</p>
                             </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                           <div className="flex items-center gap-2 text-slate-400">
                              <Calendar size={14} className="text-slate-600" />
                              <span className="text-xs font-medium">{safeDateFormat(u.createdAt, 'dd MMM yyyy')}</span>
                           </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2 text-xs">
                            <button
                              onClick={() => toggleAdmin(u)}
                              title={u.isAdmin ? "Revoke Admin Access" : "Give Admin Access"}
                              className={cn(
                                "flex items-center gap-2 px-3 py-2 rounded-xl border font-bold transition-all",
                                u.isAdmin 
                                  ? "bg-amber-500/20 border-amber-500/30 text-amber-500" 
                                  : "bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300"
                              )}
                            >
                              <ShieldCheck size={16} />
                              {u.isAdmin ? 'Admin' : 'Make Admin'}
                            </button>

                            <button
                              onClick={() => toggleBan(u)}
                              title={u.isBanned ? "Unban User" : "Ban User"}
                              className={cn(
                                "flex items-center gap-2 px-3 py-2 rounded-xl transition-all border font-bold",
                                u.isBanned 
                                  ? "bg-green-500/10 border-green-500/20 text-green-500 hover:bg-green-500/20" 
                                  : "bg-red-500/10 border-red-500/20 text-red-500 hover:bg-red-500/20"
                              )}
                            >
                              {u.isBanned ? <UserCheck size={16} /> : <Ban size={16} />}
                              {u.isBanned ? 'Unban' : 'Ban'}
                            </button>

                            <button
                              onClick={() => deleteUser(u.id)}
                              title="Delete Account"
                              className="p-2.5 bg-slate-900/50 border border-slate-800 text-slate-400 hover:text-white hover:bg-red-600 hover:border-red-600 rounded-xl transition-all"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Security Footer Info */}
      <div className="flex items-center justify-center gap-6 pt-10 text-slate-600 border-t border-slate-900">
         <div className="flex items-center gap-2">
            <ShieldCheck size={16} />
            <span className="text-[9px] font-black uppercase tracking-[0.2em]">Vault Secure Management</span>
         </div>
         <div className="flex items-center gap-2">
            <Activity size={16} />
            <span className="text-[9px] font-black uppercase tracking-[0.2em]">Real-time Presence Sync</span>
         </div>
      </div>
    </div>
  );
}
