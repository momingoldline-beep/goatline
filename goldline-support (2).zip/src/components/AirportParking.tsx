import React from 'react';
import { Plane, ParkingCircle, PoundSterling, Info } from 'lucide-react';
import { motion } from 'motion/react';

const AIRPORT_PRICES = [
  { capacity: '8-seater', price: '£160' },
  { capacity: '16-seater', price: '£250' },
  { capacity: '19-seater', price: '£250' },
  { capacity: '22-seater', price: '£300' },
  { capacity: '34-seater', price: '£400' },
  { capacity: '43-seater', price: '£500' },
  { capacity: '49-seater', price: '£500' },
  { capacity: '53-seater', price: '£500' },
  { capacity: '57-seater', price: '£500' },
  { capacity: '70-seater', price: '£600' },
  { capacity: '84-seater', price: '£700' },
  { capacity: 'Luton Van', price: '£250 + £50' },
];

const PARKING_CHARGES = [
  { location: 'Heathrow', price: '£75' },
  { location: 'Gatwick', price: '£30' },
  { location: 'Stansted', price: '£20' },
  { location: 'Luton', price: '£20' },
  { location: 'London City', price: '£25' },
  { location: 'Southend on sea', price: '£20' },
  { location: 'White wittering beach', price: '£15' },
];

export default function AirportParking() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h2 className="text-3xl font-black text-white tracking-tight">Airport & Parking</h2>
        <p className="text-sm text-slate-500 font-bold uppercase tracking-[0.2em] mt-1">Standard Rates & Pick-up Fees</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Airport Prices Table */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 px-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-500">
              <Plane size={18} />
            </div>
            <h3 className="text-lg font-bold text-white">Standard Airport Prices (Each Way)</h3>
          </div>
          
          <div className="glass rounded-[2rem] overflow-hidden border border-slate-800 shadow-2xl">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900/60 border-b border-slate-800">
                  <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Vehicle Capacity</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] text-right">Fixed Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {AIRPORT_PRICES.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/20 transition-all">
                    <td className="px-6 py-3.5 text-sm font-bold text-slate-200">{item.capacity}</td>
                    <td className="px-6 py-3.5 text-sm font-black text-amber-500 text-right">{item.price}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Parking Charges Table */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 px-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-500">
              <ParkingCircle size={18} />
            </div>
            <h3 className="text-lg font-bold text-white">Parking Charges (On Pickup)</h3>
          </div>
          
          <div className="glass rounded-[2rem] overflow-hidden border border-slate-800 shadow-2xl">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900/60 border-b border-slate-800">
                  <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Location</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] text-right">Fee</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {PARKING_CHARGES.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/20 transition-all">
                    <td className="px-6 py-3.5 text-sm font-bold text-slate-200">{item.location}</td>
                    <td className="px-6 py-3.5 text-sm font-black text-amber-500 text-right">{item.price}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="glass p-6 rounded-2xl border border-amber-500/10 bg-amber-500/5 mt-6">
            <div className="flex gap-3">
              <Info className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-slate-400 leading-relaxed italic">
                  Note: Pickup parking charges are mandatory for all airport and select coastal locations to cover waiting time and barrier fees.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
