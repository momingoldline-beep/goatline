import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Send, Copy, ArrowRight, Loader2, AlertCircle, CheckCircle2, User, MapPin, Calendar, Users, Bus, ArrowDown, Info, Clock, MessageSquare } from 'lucide-react';
import { parseQuotationInquiry } from '../services/geminiService';
import { cn } from '../lib/utils';
import { format } from 'date-fns';

interface AIChatProps {
  onParseComplete: (data: any) => void;
  persistedInput: string;
  setPersistedInput: (input: string) => void;
  persistedResult: any;
  setPersistedResult: (result: any) => void;
}

export default function AIChat({ 
  onParseComplete, 
  persistedInput, 
  setPersistedInput, 
  persistedResult, 
  setPersistedResult 
}: AIChatProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleParse = async () => {
    if (!persistedInput.trim()) return;
    
    setLoading(true);
    setError(null);
    setPersistedResult(null);

    try {
      const data = await parseQuotationInquiry(persistedInput);
      setPersistedResult(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to parse the inquiry. Please try again or enter manually.");
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => {
    setPersistedInput('');
    setPersistedResult(null);
    setError(null);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Sparkles className="text-amber-500" size={20} />
            AI Quotation Assistant
          </h2>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Multi-Movement Parsing for Inquiry Emails</p>
        </div>
      </div>

      <div className="glass p-12 rounded-3xl min-h-[600px] flex flex-col items-center justify-center text-center relative overflow-hidden">
        {/* Background Accents */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl -mr-32 -mt-32" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl -ml-32 -mb-32" />
        
        <div className="relative z-10 space-y-6">
          <div className="w-20 h-20 bg-slate-900 border border-amber-500/20 rounded-2xl flex items-center justify-center mx-auto shadow-2xl relative">
            <Sparkles className="text-amber-500 animate-pulse" size={32} />
            <div className="absolute -top-2 -right-2 bg-amber-500 text-slate-900 text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter">
              WIP
            </div>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-2xl font-black text-white tracking-tight italic uppercase">Under Maintenance</h3>
            <p className="text-slate-400 text-sm max-w-md mx-auto leading-relaxed">
              We are currently refining the AI's parsing engine to handle complex multi-leg journeys even more accurately.
            </p>
          </div>
          
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-1.5 px-4 py-2 bg-amber-500/5 border border-amber-500/10 rounded-full">
              <div className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-ping" />
              <span className="text-[10px] font-bold text-amber-500 uppercase tracking-[0.2em]">Upgrading Intelligence</span>
            </div>
            
            <p className="text-slate-600 text-[10px] font-medium uppercase tracking-widest">
              Check back soon for the updated experience.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
