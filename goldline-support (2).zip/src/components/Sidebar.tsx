import React from 'react';
import { PlusCircle, List, Settings, LogOut, LayoutDashboard, BusFront, ShieldCheck, Plane, Sparkles, Navigation, Users } from 'lucide-react';
import { cn } from '../lib/utils';

interface SidebarProps {
  activeView: 'new' | 'list' | 'vehicles' | 'parking' | 'ai-chat' | 'users';
  onViewChange: (view: 'new' | 'list' | 'vehicles' | 'parking' | 'ai-chat' | 'users') => void;
  user: any;
  onLogout: () => void;
}

export default function Sidebar({ activeView, onViewChange, user, onLogout }: SidebarProps) {
  const menuItems = [
    { id: 'ai-chat', label: 'AI Assistant', icon: Sparkles },
    { id: 'parking', label: 'Airport & Parking', icon: Plane },
    { id: 'new', label: 'New Quotation', icon: PlusCircle },
    { id: 'list', label: 'Saved Quotations', icon: List },
    { id: 'vehicles', label: 'Vehicle Details', icon: LayoutDashboard },
    { id: 'users', label: 'Staff Accounts', icon: Users },
  ];

  return (
    <aside className="w-64 flex-shrink-0 bg-slate-900 border-r border-slate-800 flex flex-col h-screen sticky top-0">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 gold-gradient rounded-lg flex items-center justify-center font-bold text-slate-900 shadow-lg shadow-amber-500/20">
            <BusFront size={24} />
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-wider uppercase text-white leading-tight">GOLDLINE</h1>
            <p className="text-[10px] text-amber-500 tracking-[0.2em] font-medium uppercase">Executive Travel</p>
          </div>
        </div>

        <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest pb-3">Navigation</div>
        <nav className="space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id as any)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group text-sm",
                activeView === item.id 
                  ? "bg-slate-900 text-amber-500 border border-slate-800" 
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-900"
              )}
            >
              <item.icon size={18} className={activeView === item.id ? "text-amber-500" : "text-slate-500 group-hover:text-amber-500"} />
              <span className="tracking-tight">{item.label}</span>
              {item.id === 'ai-chat' && (
                <span className="ml-auto text-[8px] font-black bg-amber-500 text-slate-900 px-1.5 py-0.5 rounded-full uppercase tracking-tighter">
                  WIP
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-6 space-y-4">
        {user && (
          <div className="glass bg-slate-900/50 p-4 rounded-xl flex flex-col gap-3">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full gold-gradient flex items-center justify-center text-slate-900 text-xs font-bold ring-2 ring-slate-800 overflow-hidden">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="" className="w-full h-full object-cover" />
                  ) : (
                    (user.displayName || user.email)?.[0].toUpperCase()
                  )}
                </div>
                <div className="overflow-hidden">
                  <p className="text-xs font-bold text-white truncate">{user.displayName || 'System Admin'}</p>
                  <p className="text-[10px] text-slate-400 truncate font-medium">{user.email}</p>
                </div>
             </div>
             <div className="flex items-center gap-1.5 mt-2">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span className="text-[10px] uppercase tracking-wide text-slate-300">System Active</span>
             </div>
          </div>
        )}
        
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all text-sm font-medium"
        >
          <LogOut size={18} className="text-slate-500 group-hover:text-red-400" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}
