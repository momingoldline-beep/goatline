import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BusFront, User, Lock, UserPlus, ChevronLeft, ShieldCheck, ArrowRight, X } from 'lucide-react';
import { loginWithUsername, registerWithUsername, db } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';

interface SavedProfile {
  username: string;
  displayName: string;
}

const LOCAL_STORAGE_KEY = 'goldline_auth_profiles';

export default function LoginManager() {
  const [view, setView] = useState<'profiles' | 'login' | 'register'>('profiles');
  const [profiles, setProfiles] = useState<SavedProfile[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<SavedProfile | null>(null);
  
  // Form states
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      setProfiles(parsed);
      if (parsed.length === 0) setView('login');
    } else {
      setView('login');
    }
  }, []);

  const saveProfile = (newProfile: SavedProfile) => {
    const updated = [newProfile, ...profiles.filter(p => p.username !== newProfile.username)].slice(0, 5);
    setProfiles(updated);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
  };

  const removeProfile = (e: React.MouseEvent, username: string) => {
    e.stopPropagation();
    const updated = profiles.filter(p => p.username !== username);
    setProfiles(updated);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
    if (updated.length === 0) setView('login');
  };

  const handleLogin = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!username || !password) return;
    
    setError('');
    setLoading(true);
    try {
      const userCred = await loginWithUsername(username, password);
      saveProfile({
        username: username.toLowerCase().trim(),
        displayName: userCred.user.displayName || username
      });
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password || !displayName) return;
    
    setError('');
    setLoading(true);
    try {
      await registerWithUsername(username, password, displayName);
      saveProfile({
        username: username.toLowerCase().trim(),
        displayName: displayName
      });
    } catch (err: any) {
      setError(err.message || 'Account creation failed.');
    } finally {
      setLoading(false);
    }
  };

  const selectProfile = async (p: SavedProfile) => {
    setSelectedProfile(p);
    setUsername(p.username);
    setView('login');
    setPassword('');
    setError('');
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-amber-500/5 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-amber-500/5 rounded-full blur-[120px]" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="glass bg-slate-900/80 p-8 rounded-[2.5rem] shadow-2xl border border-white/5">
          <div className="text-center mb-8">
            <motion.div 
              initial={{ y: -10 }}
              animate={{ y: 0 }}
              className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-amber-500/20"
            >
              <BusFront className="text-slate-900" size={32} />
            </motion.div>
            
            <h1 className="text-3xl font-black text-white tracking-tight mb-2">GOLDLINE</h1>
            <p className="text-amber-500/80 font-bold uppercase tracking-[0.2em] text-[10px]">Staff Support Portal</p>
          </div>

          <AnimatePresence mode="wait">
            {view === 'profiles' && (
              <motion.div
                key="profiles"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-4"
              >
                <p className="text-slate-400 text-xs font-bold uppercase tracking-widest text-center mb-6 flex items-center justify-center gap-2">
                  <User size={12} className="text-amber-500" />
                  Local Access Profiles
                </p>
                <div className="grid grid-cols-1 gap-3">
                  {profiles.map((p) => (
                    <button
                      key={p.username}
                      onClick={() => selectProfile(p)}
                      className="group flex items-center p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 transition-all w-full text-left relative"
                    >
                      <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center mr-4 group-hover:bg-amber-500/20 transition-colors">
                        <User className="text-amber-500" size={20} />
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-bold text-sm tracking-tight">{p.displayName}</p>
                        <p className="text-slate-500 text-[10px] uppercase tracking-wider font-bold">{p.username}</p>
                      </div>
                      <button 
                        onClick={(e) => removeProfile(e, p.username)}
                        className="p-2 opacity-0 group-hover:opacity-100 hover:text-red-400 text-slate-500 transition-all"
                      >
                        <X size={14} />
                      </button>
                    </button>
                  ))}
                </div>
                
                <button
                  onClick={() => {
                    setSelectedProfile(null);
                    setUsername('');
                    setPassword('');
                    setError('');
                    setView('login');
                  }}
                  className="w-full py-4 mt-4 border border-dashed border-white/10 hover:border-amber-500/30 hover:bg-amber-500/5 rounded-2xl text-slate-400 hover:text-amber-500 transition-all text-xs font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-2"
                >
                  <UserPlus size={14} />
                  Login with Existing Account
                </button>
                <p className="text-[10px] text-slate-600 text-center font-medium mt-2 px-6">
                  Accounts are saved in the cloud. You can log into your profile from any computer using your username.
                </p>
              </motion.div>
            )}

            {(view === 'login' || view === 'register') && (
              <motion.div
                key="form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="flex items-center gap-4 mb-6">
                  {profiles.length > 0 && (
                    <button 
                      onClick={() => setView('profiles')}
                      className="p-2 bg-white/5 hover:bg-white/10 rounded-xl text-slate-400 transition-colors"
                    >
                      <ChevronLeft size={16} />
                    </button>
                  )}
                  <h3 className="text-white font-bold text-lg tracking-tight">
                    {view === 'login' ? (selectedProfile ? `Welcome back, ${selectedProfile.displayName}` : 'Login') : 'Create Account'}
                  </h3>
                </div>

                <form onSubmit={view === 'login' ? handleLogin : handleRegister} className="space-y-4">
                  {view === 'register' && (
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 ml-1">Full Name</label>
                      <div className="relative">
                        <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 shrink-0" size={18} />
                        <input
                          type="text"
                          required
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                          placeholder="e.g. John Smith"
                        />
                      </div>
                    </div>
                  )}

                  {!selectedProfile && (
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 ml-1">Username</label>
                      <div className="relative">
                        <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 shrink-0" size={18} />
                        <input
                          type="text"
                          required
                          value={username}
                          onChange={(e) => setUsername(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                          placeholder="support_admin"
                        />
                      </div>
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 ml-1">Password</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 shrink-0" size={18} />
                      <input
                        type="password"
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-amber-500/50 transition-all"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>

                  {error && (
                    <motion.p 
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-400 text-xs font-medium text-center bg-red-400/10 py-2 rounded-lg border border-red-400/20"
                    >
                      {error}
                    </motion.p>
                  )}

                  <button
                    disabled={loading}
                    type="submit"
                    className="w-full py-4 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed text-slate-900 font-black rounded-2xl transition-all flex items-center justify-center gap-3 shadow-xl shadow-amber-500/10 hover:scale-[1.02] active:scale-[0.98] mt-4"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin" />
                    ) : (
                      <>
                        {view === 'login' ? 'Sign In' : 'Create Account'}
                        <ArrowRight size={18} />
                      </>
                    )}
                  </button>

                  <div className="text-center mt-6">
                    <button
                      type="button"
                      onClick={() => {
                        setView(view === 'login' ? 'register' : 'login');
                        setError('');
                        setSelectedProfile(null);
                        setUsername('');
                      }}
                      className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500 hover:text-amber-500 transition-colors"
                    >
                      {view === 'login' ? 'Create new goldline support account?' : 'Already have an account? Login'}
                    </button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="mt-8 pt-8 border-t border-white/5 flex items-center justify-center gap-2 text-slate-600 text-[10px] font-bold uppercase tracking-widest">
            <ShieldCheck size={14} />
            <span>Secure Enterprise Login</span>
          </div>
        </div>
        
        <p className="mt-8 text-center text-slate-600 text-[10px] font-bold uppercase tracking-widest">
          &copy; {new Date().getFullYear()} Goldline Executive Travel
        </p>
      </motion.div>
    </div>
  );
}
