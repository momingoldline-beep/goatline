import React from 'react';
import { Bus, Luggage, ShieldCheck, Zap, Thermometer, Wind, UserCheck } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface VehicleInfo {
  registration: string;
  type: 'Standard' | 'Executive' | 'Party Bus';
  capacity: string;
  luggage: string;
  wc?: boolean;
  ac?: boolean;
  usb?: boolean;
  extra?: string;
}

const FLEET_DATA: VehicleInfo[] = [
  // 8 Seaters
  { capacity: '8', type: 'Standard', registration: 'LP19UMS', luggage: '8M + 8 Hand carries' },
  { capacity: '8', type: 'Standard', registration: 'LO21YUV', luggage: '8M + 8 Hand carries' },
  { capacity: '8', type: 'Standard', registration: 'KV23BHI', luggage: '8M + 8 Hand carries' },
  { capacity: '8', type: 'Standard', registration: 'GF72DHJ', luggage: '8M + 8 Hand carries' },
  // 16 Seaters
  { capacity: '16', type: 'Party Bus', registration: 'CN17NKG', luggage: '9M + 9 Hand carries', extra: '2+1 party bus' },
  { capacity: '16', type: 'Standard', registration: 'LN21XKL', luggage: '8L + 8S Suitcases', extra: '12+1' },
  { capacity: '16', type: 'Executive', registration: 'GX25BYT', luggage: '16M + 16 Hand Carry', wc: true, ac: true },
  // 19 Seaters
  { capacity: '19', type: 'Executive', registration: 'YG23WWV', luggage: '10M + 9 Hand carries', wc: true, ac: true },
  { capacity: '19', type: 'Executive', registration: 'YG23WWY', luggage: '10M + 9 Hand carries', wc: true, ac: true },
  // 22 Seaters
  { capacity: '22', type: 'Executive', registration: 'VJ25VAY', luggage: '12L Suitcases + 12 hand carry', wc: true, ac: true },
  { capacity: '22', type: 'Executive', registration: 'VJ25VAX', luggage: '12L Suitcases + 12 hand carry', wc: true, ac: true },
  // 34 Seaters
  { capacity: '34', type: 'Standard', registration: 'YD73FON', luggage: '29M suitcases + 10 hand carry', wc: true },
  { capacity: '34', type: 'Executive', registration: 'YK25OGZ', luggage: '29M suitcases + 10 hand carry', wc: true, ac: true, usb: true },
  { capacity: '34', type: 'Executive', registration: 'YK25OHA', luggage: '29M suitcases + 10 hand carry', wc: true, ac: true, usb: true },
  // 43 Seater
  { capacity: '43', type: 'Executive', registration: 'YN18SVG', luggage: '34M suitcases + 10 hand carry', wc: true, ac: true, usb: true },
  // 49 Seater
  { capacity: '49', type: 'Executive', registration: 'BP23HWO', luggage: '40L suitcases + 10 hand carry', extra: '43+1', wc: true, ac: true, usb: true },
  // 53 Seater
  { capacity: '53', type: 'Executive', registration: 'YN70YRF', luggage: '50M suitcases + 10 hand carry', extra: '49+1', wc: true, ac: true, usb: true },
  { capacity: '53', type: 'Executive', registration: 'YN70YRG', luggage: '50M suitcases + 10 hand carry', extra: '49+1', wc: true, ac: true, usb: true },
  { capacity: '53', type: 'Executive', registration: 'YT24BJX', luggage: '50M suitcases + 10 hand carry', extra: '49+1', wc: true, ac: true, usb: true },
  // 57 Seater
  { capacity: '57', type: 'Standard', registration: 'YT24JHO', luggage: '50M suitcases + 10 hand carry', extra: '53+1', wc: true, usb: true },
  { capacity: '57', type: 'Executive', registration: 'BD24WZA', luggage: '50M suitcases + 10 hand carry', extra: '53+1', wc: true, ac: true, usb: true },
  { capacity: '57', type: 'Executive', registration: 'BD24WZB', luggage: '50M suitcases + 10 hand carry', extra: '53+1', wc: true, ac: true, usb: true },
  // 70 Seater
  { capacity: '70', type: 'Standard', registration: 'YN67VDA', luggage: '50M suitcases + 10 hand carry' },
  { capacity: '70', type: 'Standard', registration: 'YX22LUE', luggage: '50M suitcases + 10 hand carry' },
  { capacity: '70', type: 'Standard', registration: 'YT23HXX', luggage: '50M suitcases + 10 hand carry', extra: '64+1' },
  // 84 Seater
  { capacity: '84', type: 'Executive', registration: 'YY24GZL', luggage: 'No Luggage', extra: '83+1', ac: true },
];

export default function VehicleDetails() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h2 className="text-3xl font-black text-white tracking-tight">Vehicle Fleet</h2>
        <p className="text-sm text-slate-500 font-bold uppercase tracking-[0.2em] mt-1">Detailed Technical Specifications & Availability</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        <div className="glass rounded-[2rem] overflow-hidden border border-slate-800 shadow-2xl">
          <div className="overflow-x-auto no-scrollbar">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900/60 border-b border-slate-800">
                  <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Capacity</th>
                  <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Class</th>
                  <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Registration</th>
                  <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Luggage Configuration</th>
                  <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Features</th>
                  <th className="px-6 py-5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Configuration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {FLEET_DATA.map((v, i) => (
                  <tr key={i} className="hover:bg-slate-800/20 transition-all group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center group-hover:border-amber-500/30 transition-colors">
                          <Bus size={18} className="text-amber-500" />
                        </div>
                        <span className="text-lg font-black text-white">{v.capacity} <span className="text-[10px] text-slate-500 uppercase">Seats</span></span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[10px] font-black border uppercase tracking-widest",
                        v.type === 'Executive' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                        v.type === 'Party Bus' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
                        'bg-slate-800 text-slate-400 border-slate-700'
                      )}>
                        {v.type}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <code className="text-xs font-black text-slate-300 bg-slate-900/50 px-2 py-1 rounded border border-slate-800 font-mono tracking-wider">
                        {v.registration}
                      </code>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                        <Luggage size={14} className="text-slate-600" />
                        {v.luggage}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        {v.wc && (
                          <div className="group/tip relative">
                            <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 hover:text-amber-500 transition-colors">
                              <span className="text-[10px] font-black uppercase">WC</span>
                            </div>
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-slate-800 text-[10px] font-bold text-white rounded opacity-0 group-hover/tip:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">Toilet Equipped</div>
                          </div>
                        )}
                        {v.ac && (
                          <div className="group/tip relative">
                            <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 hover:col-blue-400 transition-colors">
                              <Wind size={14} className="group-hover:text-blue-400" />
                            </div>
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-slate-800 text-[10px] font-bold text-white rounded opacity-0 group-hover/tip:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">Air Conditioning</div>
                          </div>
                        )}
                        {v.usb && (
                          <div className="group/tip relative">
                            <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 transition-colors">
                              <Zap size={14} className="group-hover:text-green-400" />
                            </div>
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-slate-800 text-[10px] font-bold text-white rounded opacity-0 group-hover/tip:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">USB / Power Points</div>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {v.extra ? (
                        <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                          <UserCheck size={12} className="text-amber-500/50" />
                          {v.extra}
                        </div>
                      ) : (
                         <span className="text-[10px] text-slate-700 font-bold uppercase tracking-widest">Standard</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      <div className="glass p-8 rounded-[2rem] border border-slate-800/50 bg-slate-900/30 flex flex-col md:flex-row items-center gap-8">
        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 flex items-center justify-center text-amber-500 flex-shrink-0">
          <ShieldCheck size={32} />
        </div>
        <div>
          <h4 className="text-white font-bold text-lg leading-tight mb-2">Compliance & Safety Standards</h4>
          <p className="text-slate-400 text-sm leading-relaxed max-w-2xl">
            All vehicles listed above are maintained to the highest executive standards, including regular safety inspections, full comprehensive insurance, and strictly professional, licensed chauffeurs.
          </p>
        </div>
      </div>
    </div>
  );
}
