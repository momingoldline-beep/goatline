import React, { useState, useEffect } from 'react';
import { Search, Eye, Edit2, Trash2, Calendar, User, Hash, Filter, ArrowRight, Download } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, doc, deleteDoc, where } from 'firebase/firestore';
import { Quotation } from '../types';
import { cn } from '../lib/utils';
import { safeDateFormat } from '../lib/date-utils';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

interface SavedQuotationsProps {
  onEdit: (quotation: Quotation) => void;
  onView: (quotation: Quotation) => void;
}

export default function SavedQuotations({ onEdit, onView }: SavedQuotationsProps) {
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchRef, setSearchRef] = useState('');
  const [searchDate, setSearchDate] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'quotations'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Quotation[];
      setQuotations(docs);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'quotations', id));
      setDeleteConfirmId(null);
    } catch (err) {
      console.error("Error deleting document:", err);
      alert("Failed to delete quotation. Please try again.");
    }
  };

  const filteredQuotations = quotations.filter(q => {
    const matchesName = (q.customerName || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRef = (q.reference || '').toLowerCase().includes(searchRef.toLowerCase());
    const mainDate = q.movements?.[0]?.date || '';
    const matchesDate = !searchDate || mainDate === searchDate;
    return matchesName && matchesRef && matchesDate;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Draft': return 'bg-gray-100 text-gray-700 border-gray-200';
      case 'Sent': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'Confirmed': return 'bg-green-100 text-green-700 border-green-200';
      case 'Cancelled': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Saved Quotations</h2>
          <p className="text-sm text-slate-500 font-medium">Review and manage all historical quotes</p>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 glass bg-slate-900/50 p-4 rounded-xl">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
          <input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-dark w-full pl-10 pr-4 py-2 rounded-lg text-xs"
            placeholder="Search by customer name..."
          />
        </div>
        <div className="relative">
          <Hash className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
          <input
            value={searchRef}
            onChange={(e) => setSearchRef(e.target.value)}
            className="input-dark w-full pl-10 pr-4 py-2 rounded-lg text-xs"
            placeholder="Search by reference..."
          />
        </div>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
          <input
            type="date"
            value={searchDate}
            onChange={(e) => setSearchDate(e.target.value)}
            className="input-dark w-full pl-10 pr-4 py-2 rounded-lg text-xs"
          />
        </div>
      </div>

      {/* Table */}
      <div className="glass rounded-xl overflow-hidden">
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900/40 border-b border-slate-800">
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Reference</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Customer</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Pickup Date</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Route</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Vehicle</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-10 text-center text-slate-500 italic text-sm">Loading quotations...</td>
                </tr>
              ) : filteredQuotations.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-10 text-center text-slate-500 italic text-sm">No quotations found matching your criteria.</td>
                </tr>
              ) : (
                filteredQuotations.map((q) => (
                  <tr key={q.id} className="hover:bg-slate-800/40 transition-colors group">
                    <td className="px-6 py-4">
                      <span className="font-mono font-bold text-amber-500 text-xs">{q.reference}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-bold text-white">{q.customerName || 'Guest'}</div>
                      {q.createdByName && (
                        <div className="text-[9px] text-slate-500 uppercase tracking-tighter mt-0.5">
                          By: {q.createdByName.split(' ')[0]}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 text-xs">
                      {q.movements && q.movements.length > 0 ? (
                        <>
                          <div className="text-slate-200 font-medium whitespace-nowrap">
                            {safeDateFormat(q.movements[0].date, 'dd MMM yyyy', 'Date TBC')}
                          </div>
                          <div className="text-amber-500 font-bold tracking-tighter uppercase text-[9px] mt-0.5">
                            {q.movements.length} {q.movements.length === 1 ? 'Movement' : 'Movements'}
                          </div>
                        </>
                      ) : (
                        <span className="text-slate-500">N/A</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {q.movements && q.movements.length > 0 ? (
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 max-w-xs truncate">
                          <span className="truncate">{q.movements[0].outbound.pickup || 'Start'}</span>
                          <ArrowRight size={12} className="flex-shrink-0 text-amber-500/50" />
                          <span className="truncate text-slate-200 font-medium">
                            {q.movements[0].outbound.destination || 'End'}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-500 text-xs">Unspecified</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-xs">
                      <div className="text-slate-200 font-bold">{q.movements?.[0]?.vehicleCapacity || 'TBC'}</div>
                      <div className="text-slate-500">{q.vehicleType} · {q.passengers} pax</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[9px] font-bold border uppercase tracking-widest",
                        getStatusColor(q.status)
                      )}>
                        {q.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            onView(q);
                          }}
                          className="p-2 text-slate-400 hover:text-amber-500 hover:bg-slate-800 rounded-lg transition-all"
                          title="View Details"
                        >
                          <Eye size={18} />
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            onEdit(q);
                          }}
                          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all"
                          title="Edit"
                        >
                          <Edit2 size={18} />
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            if (q.id) setDeleteConfirmId(q.id);
                          }}
                          className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
                          title="Delete"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modern Center Modal Bottom-Slide Delete Confirmation */}
      <AnimatePresence>
        {deleteConfirmId && (
          <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeleteConfirmId(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            
            {/* Modal Content */}
            <motion.div
              initial={{ opacity: 0, y: 100, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 100, scale: 0.95 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative w-full max-w-sm glass bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden p-6 text-center"
            >
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-red-500/20">
                <Trash2 size={28} className="text-red-500" />
              </div>
              
              <h3 className="text-lg font-bold text-white mb-2">Delete Quotation?</h3>
              <p className="text-sm text-slate-400 mb-8">
                Are you sure you want to delete this quote? This action cannot be undone and will permanently remove all data.
              </p>
              
              <div className="flex flex-col gap-3">
                <button 
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="w-full py-3 bg-red-600 text-white text-sm font-bold rounded-xl hover:bg-red-500 transition-all shadow-lg shadow-red-600/20 active:scale-95"
                >
                  Confirm Delete
                </button>
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="w-full py-3 bg-slate-800 text-slate-300 text-sm font-bold rounded-xl border border-slate-700 hover:bg-slate-700 transition-all active:scale-95"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
