import React, { useState, useEffect, useRef } from 'react';
import { 
  Plus, Trash2, Save, XCircle, ChevronDown, ChevronUp, Info, 
  Calendar as CalendarIcon, Clock, ChevronLeft, ChevronRight,
  MoveHorizontal, ArrowRight
} from 'lucide-react';
import { Quotation, VehicleCapacity, VehicleType, Movement } from '../types';
import { cn } from '../lib/utils';
import { cleanObject } from '../lib/firestore-utils';
import { generateReference } from '../lib/id-generator';
import { db, auth } from '../lib/firebase';
import { collection, addDoc, serverTimestamp, doc, updateDoc } from 'firebase/firestore';
import { 
  format, addMonths, subMonths, startOfMonth, endOfMonth, 
  startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, 
  isSameDay, isToday, parseISO 
} from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

// --- Custom Components ---

interface CustomPickerProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: { label: string; value: string }[];
  placeholder?: string;
  icon?: React.ReactNode;
  required?: boolean;
  disabled?: boolean;
}

const CustomSearchableSelect = ({ label, value, onChange, options, placeholder, icon, required, disabled }: CustomPickerProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredOptions = options.filter(opt => 
    opt.label.toLowerCase().includes(search.toLowerCase())
  );

  const selectedOption = options.find(opt => opt.value === value);

  return (
    <div className={cn("space-y-1.5 relative", disabled && "opacity-60")} ref={containerRef}>
      <label className="text-[10px] uppercase font-semibold text-slate-400">{label} {required && '*'}</label>
      <button
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "input-dark w-full px-3 py-2 rounded-lg text-sm flex items-center justify-between text-left transition-all",
          isOpen ? "border-amber-500/50 ring-1 ring-amber-500/20" : "border-slate-800",
          disabled && "cursor-not-allowed bg-slate-900/50"
        )}
      >
        <div className="flex items-center gap-2 truncate">
          {icon}
          <span className={cn(value ? "text-slate-100" : "text-slate-500")}>
            {selectedOption ? selectedOption.label : placeholder || 'Select...'}
          </span>
        </div>
        <ChevronDown size={14} className={cn("text-slate-500 transition-transform", isOpen && "rotate-180")} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute z-50 w-full mt-2 glass bg-slate-900 border border-slate-800 rounded-xl shadow-2xl max-h-64 flex flex-col"
          >
            <div className="p-2 border-b border-slate-800">
              <input
                autoFocus
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Type to search..."
                className="w-full bg-slate-900 border border-slate-800 rounded-md px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>
            <div className="overflow-y-auto no-scrollbar py-1">
              {filteredOptions.length > 0 ? (
                filteredOptions.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => {
                      onChange(opt.value);
                      setIsOpen(false);
                      setSearch('');
                    }}
                    className={cn(
                      "w-full px-4 py-2 text-left text-xs transition-colors hover:bg-amber-500/10 hover:text-amber-500",
                      value === opt.value ? "bg-amber-500/10 text-amber-500 font-bold" : "text-slate-300"
                    )}
                  >
                    {opt.label}
                  </button>
                ))
              ) : (
                <div className="px-4 py-3 text-xs text-slate-500 text-center italic">No results found</div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const CustomTimePicker = ({ label, value, onChange, options, icon, required }: CustomPickerProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredOptions = options.filter(opt => 
    opt.label.toLowerCase().includes(value.toLowerCase())
  );

  return (
    <div className="space-y-1.5 relative" ref={containerRef}>
      <label className="text-[10px] uppercase font-semibold text-slate-400">{label} {required && '*'}</label>
      <div className={cn(
        "input-dark w-full px-3 py-2 rounded-lg text-sm flex items-center gap-2 border transition-all focus-within:border-amber-500/50 focus-within:ring-1 focus-within:ring-amber-500/20",
        isOpen ? "border-amber-500/50 ring-1 ring-amber-500/20" : "border-slate-800"
      )}>
        {icon}
        <input
          required={required}
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setIsOpen(true)}
          placeholder="HH:MM"
          className="bg-transparent border-none outline-none w-full text-slate-100 placeholder:text-slate-600"
          maxLength={5}
        />
        <button type="button" onClick={() => setIsOpen(!isOpen)}>
          <ChevronDown size={14} className={cn("text-slate-500 transition-transform", isOpen && "rotate-180")} />
        </button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute z-50 w-full mt-2 glass bg-slate-900 border border-slate-800 rounded-xl shadow-2xl max-h-48 overflow-y-auto no-scrollbar flex flex-col py-1"
          >
            {filteredOptions.length > 0 ? (
              filteredOptions.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => {
                    onChange(opt.value);
                    setIsOpen(false);
                  }}
                  className={cn(
                    "w-full px-4 py-2 text-left text-xs transition-colors hover:bg-amber-500/10 hover:text-amber-500",
                    value === opt.value ? "bg-amber-500/10 text-amber-500 font-bold" : "text-slate-300"
                  )}
                >
                  {opt.label}
                </button>
              ))
            ) : (
              <div className="px-4 py-3 text-[10px] text-slate-500 text-center italic">Type any specific time...</div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const CustomDatePicker = ({ label, value, onChange, required }: { label: string; value: string; onChange: (v: string) => void; required?: boolean }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(value ? parseISO(value) : new Date());
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const days = eachDayOfInterval({
    start: startOfWeek(startOfMonth(currentMonth)),
    end: endOfWeek(endOfMonth(currentMonth)),
  });

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));

  return (
    <div className="space-y-1.5 relative" ref={containerRef}>
      <label className="text-[10px] uppercase font-semibold text-slate-400">{label} {required && '*'}</label>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "input-dark w-full px-3 py-2 rounded-lg text-sm flex items-center justify-between text-left transition-all",
          isOpen ? "border-amber-500/50 ring-1 ring-amber-500/20" : "border-slate-800"
        )}
      >
        <div className="flex items-center gap-2">
          <CalendarIcon size={14} className="text-amber-500" />
          <span className={cn(value ? "text-slate-100" : "text-slate-500")}>
            {value ? format(parseISO(value), 'EEE, dd MMM yyyy') : 'Select Date'}
          </span>
        </div>
        <ChevronDown size={14} className={cn("text-slate-500 transition-transform", isOpen && "rotate-180")} />
      </button>

      <AnimatePresence mode="wait">
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute z-50 mt-2 p-4 glass bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl w-72"
          >
            <div className="flex justify-between items-center mb-4">
              <button type="button" onClick={prevMonth} className="p-1 hover:bg-slate-800 rounded-md transition-colors">
                <ChevronLeft size={16} className="text-slate-400 hover:text-amber-500" />
              </button>
              <h4 className="text-xs font-bold text-white uppercase tracking-widest">
                {format(currentMonth, 'MMMM yyyy')}
              </h4>
              <button type="button" onClick={nextMonth} className="p-1 hover:bg-slate-800 rounded-md transition-colors">
                <ChevronRight size={16} className="text-slate-400 hover:text-amber-500" />
              </button>
            </div>

            <div className="grid grid-cols-7 gap-1 mb-2">
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
                <div key={i} className="text-[10px] font-bold text-slate-500 text-center py-1">{d}</div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-1">
              {days.map((day, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    onChange(format(day, 'yyyy-MM-dd'));
                    setIsOpen(false);
                  }}
                  className={cn(
                    "aspect-square text-[11px] rounded-lg flex items-center justify-center transition-all",
                    !isSameMonth(day, currentMonth) ? "text-slate-700 pointer-events-none" : "text-slate-300 hover:bg-amber-500/10 hover:text-amber-500",
                    value && isSameDay(day, parseISO(value)) && "bg-amber-500 text-slate-900 font-bold",
                    isToday(day) && !isSameDay(day, parseISO(value)) && "border border-amber-500/30 text-amber-500"
                  )}
                >
                  {format(day, 'd')}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Form Constants ---

const VEHICLE_CAPACITIES: VehicleCapacity[] = [
  '8 Seater', '16 Seater', '19 Seater', '22 Seater', '34 Seater', 
  '43 Seater', '49 Seater', '53 Seater', '57 Seater', '70 Seater', '84 Seater'
];

const VEHICLE_TYPES: VehicleType[] = ['Standard', 'Executive', 'Party Bus'];

const TIME_SLOTS = Array.from({ length: 96 }, (_, i) => {
  const hours = Math.floor(i / 4).toString().padStart(2, '0');
  const minutes = ((i % 4) * 15).toString().padStart(2, '0');
  return `${hours}:${minutes}`;
});

interface QuotationFormProps {
  initialData?: Quotation;
  onSuccess: () => void;
  onCancel: () => void;
}

const createDefaultMovement = (index: number): Movement => ({
  id: crypto.randomUUID(),
  date: '',
  outbound: { time: '', pickup: '', destination: '' },
  additionalPickups: [],
  returnRequired: false,
  passengers: 1,
  vehicleCapacity: '16 Seater',
  vehicleQuantity: 1,
  notes: ''
});

export default function QuotationForm({ initialData, onSuccess, onCancel }: QuotationFormProps) {
  const [formData, setFormData] = useState<Omit<Quotation, 'id' | 'createdAt' | 'updatedAt'>>({
    reference: initialData?.reference || generateReference(),
    customerName: initialData?.customerName || '',
    customerEmail: initialData?.customerEmail || '',
    customerPhone: initialData?.customerPhone || '',
    movements: initialData?.movements || [createDefaultMovement(0)],
    totalPassengers: initialData?.totalPassengers || 1,
    wheelchairs: initialData?.wheelchairs || 0,
    extraLuggage: initialData?.extraLuggage || '',
    additionalNotes: initialData?.additionalNotes || '',
    unrelatedNotes: initialData?.unrelatedNotes || '',
    vehicleType: initialData?.vehicleType || 'Executive',
    internalNotes: initialData?.internalNotes || '',
    status: initialData?.status || 'Draft',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // 1. Sync m.passengers with separateVehicleSpecs if they exist and are being used
    const updatedMovements = formData.movements.map(m => {
      if (m.vehicleQuantity > 1 && m.separateVehicleSpecs && m.separateVehicleSpecs.length > 0) {
        const specsSum = m.separateVehicleSpecs.reduce((acc, s) => acc + (s.pax || 0), 0);
        if (specsSum !== m.passengers) {
          return { ...m, passengers: specsSum };
        }
      }
      return m;
    });

    const movementsChanged = JSON.stringify(updatedMovements) !== JSON.stringify(formData.movements);
    
    // 2. Calculate global total
    const globalSum = updatedMovements.reduce((acc, m) => acc + (m.passengers || 0), 0);
    
    if (movementsChanged || globalSum !== formData.totalPassengers) {
      setFormData(prev => ({ 
        ...prev, 
        movements: updatedMovements,
        totalPassengers: globalSum 
      }));
    }
  }, [formData.movements, formData.totalPassengers]);

  const handleGlobalChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const updateMovement = (index: number, field: string, value: any) => {
    setFormData(prev => {
      const newMovements = [...prev.movements];
      const keys = field.split('.');
      if (keys.length === 2) {
        // Handle outbound.time, return.pickup etc
        const [parent, child] = keys as [keyof Movement, string];
        (newMovements[index][parent] as any) = { ...(newMovements[index][parent] as any), [child]: value };
      } else {
        (newMovements[index] as any)[field] = value;
      }
      
      // Auto-logic for returns
      if (field === 'returnRequired' && value === true && !newMovements[index].return) {
        newMovements[index].return = {
          time: '',
          pickup: newMovements[index].outbound.destination,
          destination: newMovements[index].outbound.pickup
        };
      }
      
      return { ...prev, movements: newMovements };
    });
  };

  const addMovement = () => {
    setFormData(prev => ({
      ...prev,
      movements: [...prev.movements, createDefaultMovement(prev.movements.length)]
    }));
  };

  const removeMovement = (index: number) => {
    if (formData.movements.length === 1) return;
    setFormData(prev => ({
      ...prev,
      movements: prev.movements.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Basic Validation
    if (!formData.customerEmail.trim()) {
      setError("Customer Email is required.");
      setLoading(false);
      return;
    }

    try {
      if (initialData?.id) {
        const docRef = doc(db, 'quotations', initialData.id);
        await updateDoc(docRef, cleanObject({
          ...formData,
          updatedAt: serverTimestamp(),
        }));
      } else {
        await addDoc(collection(db, 'quotations'), cleanObject({
          ...formData,
          createdBy: auth.currentUser?.uid || null,
          createdByEmail: auth.currentUser?.email || 'Unknown',
          createdByName: auth.currentUser?.displayName || 'Unknown',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        }));
      }
      setLoading(false);
      onSuccess();
    } catch (err: any) {
      console.error("Error saving quotation:", err);
      
      let errorMessage = err.message || "Failed to save quotation.";
      
      if (errorMessage.includes("insufficient permissions")) {
        errorMessage = "Permission Denied: Ensure you are logged in and all required fields (Movements, Dates, and Email) are correctly filled. (Technical: Firestore Security Rules block)";
      }
      
      setError(errorMessage);
      setLoading(false);
    }
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      onKeyDown={(e) => {
        if (e.key === 'Enter' && (e.target as HTMLElement).tagName !== 'TEXTAREA') {
          e.preventDefault();
        }
      }}
      className="space-y-8 max-w-5xl mx-auto pb-20"
    >
      <div className="flex justify-between items-center border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white">{initialData ? 'Edit Quotation' : 'Create Multi-Movement Quotation'}</h2>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Ref: {formData.reference}</p>
        </div>
        <div className="flex gap-3">
          <button type="submit" disabled={loading} className="px-6 py-2 text-xs font-bold text-slate-900 gold-gradient rounded-lg shadow-xl shadow-amber-600/20 active:scale-[0.98] transition-all flex items-center gap-2 disabled:opacity-50">
            <Save size={14} /> {loading ? 'Saving...' : 'SAVE QUOTATION'}
          </button>
        </div>
      </div>

      {error && <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-lg text-sm">{error}</div>}

      {/* Basic Info */}
      <section className="glass p-6 rounded-2xl space-y-6">
        <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-4">1. Basic Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase font-semibold text-slate-400">Customer Name</label>
            <input name="customerName" value={formData.customerName} onChange={handleGlobalChange} className="input-dark w-full px-3 py-2 rounded-lg text-sm" placeholder="e.g. John Smith" />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase font-semibold text-slate-400">Email *</label>
            <input required type="email" name="customerEmail" value={formData.customerEmail} onChange={handleGlobalChange} className="input-dark w-full px-3 py-2 rounded-lg text-sm" placeholder="john@example.com" />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase font-semibold text-slate-400">Phone (Optional)</label>
            <input name="customerPhone" value={formData.customerPhone} onChange={handleGlobalChange} className="input-dark w-full px-3 py-2 rounded-lg text-sm" placeholder="+44..." />
          </div>
        </div>
      </section>

      {/* Movements Wrapper */}
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500">2. Journey Movements</h3>
          <button type="button" onClick={addMovement} className="flex items-center gap-2 px-3 py-1.5 bg-amber-500/10 text-amber-500 rounded-md text-[10px] font-bold uppercase tracking-widest hover:bg-amber-500/20 transition-all border border-amber-500/20">
            <Plus size={14} /> Add Movement
          </button>
        </div>

        <AnimatePresence initial={false}>
          {formData.movements.map((m, idx) => (
            <motion.div 
              key={m.id}
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="glass p-6 rounded-2xl border border-slate-800 relative space-y-6"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-2">
                <div className="flex items-center gap-3">
                   <div className="w-6 h-6 rounded-full bg-amber-500 flex items-center justify-center text-slate-900 text-xs font-black">
                     {idx + 1}
                   </div>
                   <span className="text-xs font-bold text-white uppercase tracking-widest">Movement {idx + 1}</span>
                </div>
                {formData.movements.length > 1 && (
                  <button type="button" onClick={() => removeMovement(idx)} className="text-slate-600 hover:text-red-500 transition-colors">
                    <Trash2 size={16} />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                 <div className="md:col-span-1">
                   <CustomDatePicker label="Date" value={m.date} onChange={(v) => updateMovement(idx, 'date', v)} required />
                 </div>
                 <div className="md:col-span-1">
                   <CustomSearchableSelect 
                    label="Vehicle Capacity" 
                    value={m.vehicleQuantity > 1 ? 'Multiple (See Loadout)' : m.vehicleCapacity} 
                    onChange={(v) => updateMovement(idx, 'vehicleCapacity', v)} 
                    options={VEHICLE_CAPACITIES.map(c => ({ label: c, value: c }))} 
                    icon={<BusFront size={14} className="text-amber-500" />}
                    disabled={m.vehicleQuantity > 1}
                   />
                 </div>
                 <div className="md:col-span-1">
                    <label className="text-[10px] uppercase font-semibold text-slate-400">Pax Qty</label>
                    <input type="number" min="1" value={m.passengers} onChange={(e) => updateMovement(idx, 'passengers', parseInt(e.target.value))} className="input-dark w-full px-3 py-2 rounded-lg text-sm" />
                 </div>
                 <div className="md:col-span-1">
                    <label className="text-[10px] uppercase font-semibold text-slate-400">Vehicles Qty</label>
                    <input type="number" min="1" value={m.vehicleQuantity} onChange={(e) => updateMovement(idx, 'vehicleQuantity', parseInt(e.target.value))} className="input-dark w-full px-3 py-2 rounded-lg text-sm" />
                 </div>
                 <div className="md:col-span-1 flex items-end">
                    <button type="button" onClick={() => updateMovement(idx, 'returnRequired', !m.returnRequired)} className={cn("w-full py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest border transition-all", m.returnRequired ? "bg-amber-500/10 border-amber-500/50 text-amber-500" : "bg-slate-900 border-slate-800 text-slate-500 hover:border-slate-700")}>
                      {m.returnRequired ? 'Return Journey' : 'Single Journey'}
                    </button>
                 </div>
              </div>

              {/* Outbound */}
              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 space-y-4">
                 <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <ArrowRight size={14} className="text-green-500" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-slate-300">Outbound Journey</span>
                    </div>
                    <button 
                      type="button" 
                      onClick={() => {
                        const newPickups = [...m.additionalPickups, { location: '', time: '' }];
                        updateMovement(idx, 'additionalPickups', newPickups);
                      }}
                      className="text-[9px] font-bold text-amber-500 uppercase hover:underline"
                    >
                      + Add Waypoint
                    </button>
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="md:col-span-1">
                       <CustomTimePicker label="Time" value={m.outbound.time} onChange={(v) => updateMovement(idx, 'outbound.time', v)} options={TIME_SLOTS.map(t => ({ label: t, value: t }))} icon={<Clock size={14} className="text-amber-500" />} required />
                    </div>
                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                       <div className="space-y-1.5">
                          <label className="text-[10px] uppercase font-semibold text-slate-400">Pickup *</label>
                          <input required value={m.outbound.pickup} onChange={(e) => updateMovement(idx, 'outbound.pickup', e.target.value)} className="input-dark w-full px-3 py-2 rounded-lg text-xs" placeholder="Pickup Address" />
                       </div>
                       <div className="space-y-1.5">
                          <label className="text-[10px] uppercase font-semibold text-slate-400">Destination *</label>
                          <input required value={m.outbound.destination} onChange={(e) => updateMovement(idx, 'outbound.destination', e.target.value)} className="input-dark w-full px-3 py-2 rounded-lg text-xs" placeholder="Dropoff Address" />
                       </div>
                    </div>
                 </div>

                 {/* Additional Waypoints */}
                 {m.additionalPickups.map((p, pIdx) => (
                   <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} key={pIdx} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end bg-slate-900/40 p-3 rounded-lg border border-slate-800/50">
                      <div className="md:col-span-1">
                        <CustomTimePicker label={`Waypoint ${pIdx+1} Time`} value={p.time} onChange={(v) => {
                          const newPickups = [...m.additionalPickups];
                          newPickups[pIdx].time = v;
                          updateMovement(idx, 'additionalPickups', newPickups);
                        }} options={TIME_SLOTS.map(t => ({ label: t, value: t }))} icon={<Clock size={14} className="text-slate-500" />} />
                      </div>
                      <div className="md:col-span-2">
                         <label className="text-[10px] uppercase font-semibold text-slate-400">Waypoint Location</label>
                         <input value={p.location} onChange={(e) => {
                           const newPickups = [...m.additionalPickups];
                           newPickups[pIdx].location = e.target.value;
                           updateMovement(idx, 'additionalPickups', newPickups);
                         }} className="input-dark w-full px-3 py-2 rounded-lg text-xs" placeholder="Stop address" />
                      </div>
                      <div className="md:col-span-1 text-right">
                         <button type="button" onClick={() => {
                           const newPickups = m.additionalPickups.filter((_, i) => i !== pIdx);
                           updateMovement(idx, 'additionalPickups', newPickups);
                         }} className="text-red-500 hover:text-red-400 text-[9px] uppercase font-bold">Remove</button>
                      </div>
                   </motion.div>
                 ))}
              </div>

              {/* Return (Conditional) - Reordered above Vehicle Loadout */}
              {m.returnRequired && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/20 space-y-4">
                   <div className="flex items-center gap-2 mb-2">
                      <MoveHorizontal size={14} className="text-amber-500" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-amber-500">Return Journey</span>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="md:col-span-1">
                         <CustomTimePicker label="Return Time" value={m.return?.time || ''} onChange={(v) => updateMovement(idx, 'return.time', v)} options={TIME_SLOTS.map(t => ({ label: t, value: t }))} icon={<Clock size={14} className="text-amber-500" />} required />
                      </div>
                      <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                         <div className="space-y-1.5">
                            <label className="text-[10px] uppercase font-semibold text-slate-400">Pickup</label>
                            <input value={m.return?.pickup || ''} onChange={(e) => updateMovement(idx, 'return.pickup', e.target.value)} className="input-dark w-full px-3 py-2 rounded-lg text-xs border-amber-500/20" />
                         </div>
                         <div className="space-y-1.5">
                            <label className="text-[10px] uppercase font-semibold text-slate-400">Back To</label>
                            <input value={m.return?.destination || ''} onChange={(e) => updateMovement(idx, 'return.destination', e.target.value)} className="input-dark w-full px-3 py-2 rounded-lg text-xs border-amber-500/20" />
                         </div>
                      </div>
                   </div>
                </motion.div>
              )}

              {/* Multiple Vehicles Detail */}
              {m.vehicleQuantity > 1 && (
                <div className="p-4 rounded-xl bg-slate-900/30 border border-slate-800/50 space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 italic">Detailed Vehicle Loadout</p>
                    <button 
                      type="button" 
                      onClick={() => {
                        const currentSpecs = m.separateVehicleSpecs || [];
                        if (currentSpecs.length === 0) {
                          const specs = Array.from({ length: m.vehicleQuantity }).map(() => ({ capacity: m.vehicleCapacity, pax: Math.floor(m.passengers / m.vehicleQuantity) }));
                          updateMovement(idx, 'separateVehicleSpecs', specs);
                        } else {
                          // Remove the field rather than setting to undefined
                          const { separateVehicleSpecs, ...rest } = m;
                          const newMovements = [...formData.movements];
                          newMovements[idx] = rest as Movement;
                          setFormData(prev => ({ ...prev, movements: newMovements }));
                        }
                      }}
                      className="text-[9px] font-bold text-amber-500 uppercase"
                    >
                      {m.separateVehicleSpecs ? "Use Identical Specs" : "Specify Individual Vehicles"}
                    </button>
                  </div>
                  
                  {m.separateVehicleSpecs && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {m.separateVehicleSpecs.map((spec, sIdx) => (
                        <div key={sIdx} className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 space-y-3">
                          <p className="text-[8px] font-black text-amber-500 uppercase">Vehicle #{sIdx + 1}</p>
                          <CustomSearchableSelect 
                            label="Capacity" 
                            value={spec.capacity} 
                            onChange={(v) => {
                              const newSpecs = [...(m.separateVehicleSpecs || [])];
                              newSpecs[sIdx].capacity = v as VehicleCapacity;
                              updateMovement(idx, 'separateVehicleSpecs', newSpecs);
                            }} 
                            options={VEHICLE_CAPACITIES.map(c => ({ label: c, value: c }))} 
                          />
                          <div className="space-y-1">
                            <label className="text-[10px] text-slate-500 uppercase font-bold">Pax</label>
                            <input type="number" value={spec.pax} onChange={(e) => {
                              const newSpecs = [...(m.separateVehicleSpecs || [])];
                              newSpecs[sIdx].pax = parseInt(e.target.value);
                              updateMovement(idx, 'separateVehicleSpecs', newSpecs);
                            }} className="input-dark w-full px-3 py-1.5 rounded-lg text-xs" />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Final Details */}
      <section className="glass p-6 rounded-2xl space-y-6">
         <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500">3. Additional Details & Internal Notes</h3>
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-1.5">
               <label className="text-[10px] uppercase font-semibold text-slate-400">Total Passengers (Global) *</label>
               <input disabled type="number" name="totalPassengers" value={formData.totalPassengers} className="input-dark w-full px-3 py-2 rounded-lg text-sm bg-slate-900/50 cursor-not-allowed text-amber-500 font-black" />
            </div>
            <div className="space-y-1.5">
               <label className="text-[10px] uppercase font-semibold text-slate-400">Vehicle Type</label>
               <CustomSearchableSelect label="Type" value={formData.vehicleType} onChange={(v) => setFormData(p => ({ ...p, vehicleType: v as VehicleType }))} options={VEHICLE_TYPES.map(t => ({ label: t, value: t }))} />
            </div>
            <div className="space-y-1.5">
               <label className="text-[10px] uppercase font-semibold text-slate-400">Wheelchairs</label>
               <input type="number" name="wheelchairs" value={formData.wheelchairs} onChange={handleGlobalChange} className="input-dark w-full px-3 py-2 rounded-lg text-sm" />
            </div>
         </div>
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            <div className="space-y-1.5">
               <label className="text-[10px] uppercase font-semibold text-slate-400">Extra Luggage</label>
               <input name="extraLuggage" value={formData.extraLuggage} onChange={handleGlobalChange} className="input-dark w-full px-3 py-2 rounded-lg text-sm" placeholder="e.g. Golf clubs" />
            </div>
            <div className="space-y-1.5">
               <label className="text-[10px] uppercase font-semibold text-slate-400">Visible Notes</label>
               <textarea name="additionalNotes" value={formData.additionalNotes} onChange={handleGlobalChange} rows={3} className="input-dark w-full px-3 py-2 rounded-lg text-xs no-scrollbar" placeholder="Visible to customer..." />
            </div>
            <div className="space-y-1.5">
               <label className="text-[10px] uppercase font-semibold text-red-400/80">Unrelated Mentionings</label>
               <textarea name="unrelatedNotes" value={formData.unrelatedNotes} onChange={handleGlobalChange} rows={3} className="input-dark w-full px-3 py-2 rounded-lg text-xs no-scrollbar border-red-900/30" placeholder="Chatter, signatures, etc..." />
            </div>
         </div>
         <div className="pt-2">
            <div className="space-y-1.5">
               <label className="text-[10px] uppercase font-semibold text-amber-600/80">Staff Internal Analysis (Office Only)</label>
               <textarea name="internalNotes" value={formData.internalNotes} onChange={handleGlobalChange} rows={2} className="input-dark w-full px-3 py-2 rounded-lg text-xs no-scrollbar border-amber-900/30" placeholder="AI reasoning or office notes..." />
            </div>
         </div>
      </section>
    </form>
  );
}

const BusFront = ({ size, className }: { size: number, className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 11V9a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2" />
    <path d="M4 18h16" />
    <path d="M6 21v-3" />
    <path d="M18 21v-3" />
    <rect width="18" height="12" x="3" y="7" rx="2" />
    <path d="M8 11h.01" /><path d="M16 11h.01" />
  </svg>
);
