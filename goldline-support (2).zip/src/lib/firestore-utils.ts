/**
 * Recursively removes all undefined fields from an object.
 * Useful for Firestore which does not support undefined values.
 */
export function cleanObject(obj: any): any {
  if (Array.isArray(obj)) {
    return obj.map((item: any) => cleanObject(item));
  }
  if (obj !== null && typeof obj === 'object') {
    return Object.keys(obj).reduce((acc: any, key) => {
      const value = obj[key];
      if (value !== undefined) {
        acc[key] = cleanObject(value);
      }
      return acc;
    }, {});
  }
  return obj;
}
