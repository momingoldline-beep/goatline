import { format } from "date-fns";

export const safeDateFormat = (dateStr: string | undefined | null, formatStr: string, fallback: string = 'Date TBC') => {
  if (!dateStr) return fallback;
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return fallback;
    return format(date, formatStr);
  } catch (e) {
    return fallback;
  }
};
